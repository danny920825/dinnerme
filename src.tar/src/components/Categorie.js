import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React, { Component } from 'react'
import { Dropdown } from 'react-bootstrap'

export default class Categorie extends Component {

    render() {
        
        return (
            // <></>
            <Dropdown.Item href="#/action-1"> <FontAwesomeIcon icon={this.props.icon} />{this.props.name}</Dropdown.Item>
        )
    }
}
