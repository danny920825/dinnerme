import React, { Component } from 'react'
import { Nav,Navbar, Container, Dropdown } from 'react-bootstrap'
import "../assets/css/navbar.css";
import Categories from './Categories';

export default class Header extends Component {
    render() {
        return (
            <>
            <Navbar bg="success" sticky="top" variant="dark">
                <Container>
                    <Navbar.Brand href="#home">Dinner.me</Navbar.Brand>
                    <Nav className="me-auto">
                        <Nav.Link href="/">Inicio</Nav.Link>
                        <Nav.Link href="/places">Explorar</Nav.Link>
                        <Dropdown>
                        <Dropdown.Toggle variant="success" id="dropdown-basic">
                            Categorias
                        </Dropdown.Toggle>

                        <Dropdown.Menu>
                            <Categories/>
                        </Dropdown.Menu>
                        </Dropdown>
                    </Nav>
                </Container>
            </Navbar>
          </>
        )
    }
}
