import React, { Component } from 'react'
import Parse from 'parse/dist/parse.min.js';
import Categorie from './Categorie';
// import Categorie from './Categorie';
// import { Dropdown } from 'react-bootstrap';







export default class Categories extends Component {
    
    state = {
        categorias: {
            nombre: [],
            icon: []
        }
        
    }

    async componentDidMount(){
        try {
            const Categoria = Parse.Object.extend('Categoria');
            const query = new Parse.Query(Categoria);
            const results = await query.find();
            // const data = await Categories.findAll();
            
            for (const object of results) {
                
                // Access the Parse Object attributes using the .GET method [... object.get('categoria')]
                this.setState({categorias: {nombre: this.state.categorias.nombre.concat(object.get('categoria')), icon: this.state.categorias.icon.concat(object.get('icon'))}})
                // <Categorie name={object.get('categoria')} icon={object.get('icon')} />
                
            }
        } catch (error) {
            console.log('Error Recibiendo las categorias: ', error);
        }
        
    }


    render() {

        console.log(this.state.categorias)
        return (
            this.state.categorias.map((nombre,icon)=>{
                <Categorie name={nombre} icon={icon} />
            })
            
        )
    }
}
